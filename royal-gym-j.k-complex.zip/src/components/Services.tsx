import React from 'react';
import { motion } from 'motion/react';
import { Dumbbell, Zap, Heart, ArrowRight } from 'lucide-react';

const Services = () => {
  const services = [
    {
      title: 'Personal Training',
      description: 'One-on-one sessions tailored to your specific goals, body type, and fitness level.',
      icon: <Dumbbell className="w-8 h-8" />,
      image: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?q=80&w=2069&auto=format&fit=crop',
    },
    {
      title: 'Weight Loss Training',
      description: 'High-intensity programs designed to burn fat efficiently while building lean muscle.',
      icon: <Zap className="w-8 h-8" />,
      image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=2070&auto=format&fit=crop',
    },
    {
      title: 'Yoga Classes',
      description: 'Improve flexibility, balance, and mental clarity with our expert-led yoga sessions.',
      icon: <Heart className="w-8 h-8" />,
      image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=2020&auto=format&fit=crop',
    },
  ];

  return (
    <section id="services" className="py-24 bg-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-yellow-400 font-bold uppercase tracking-widest text-sm mb-4 block"
          >
            What We Offer
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-black font-display uppercase italic text-white"
          >
            Premium <span className="text-yellow-400">Services</span>
          </motion.h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-3xl bg-zinc-950 border border-white/5 hover:border-yellow-400/50 transition-all duration-500"
            >
              {/* Image Background */}
              <div className="absolute inset-0 z-0 opacity-20 group-hover:opacity-40 transition-opacity duration-500">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/80 to-transparent" />
              </div>

              <div className="relative z-10 p-10 h-full flex flex-col">
                <div className="w-16 h-16 rounded-2xl bg-yellow-400 text-black flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-500 shadow-[0_0_20px_rgba(250,204,21,0.3)]">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-black text-white mb-4 uppercase italic tracking-tight">
                  {service.title}
                </h3>
                <p className="text-zinc-400 mb-8 leading-relaxed">
                  {service.description}
                </p>
                <div className="mt-auto">
                  <button className="flex items-center gap-2 text-yellow-400 font-bold uppercase tracking-widest text-xs group/btn">
                    Learn More <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-2 transition-transform" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
