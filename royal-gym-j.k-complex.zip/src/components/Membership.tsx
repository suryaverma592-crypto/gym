import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Zap, X, Send } from 'lucide-react';

const Membership = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [formData, setFormData] = useState({ name: '', phone: '' });

  const plans = [
    {
      name: 'Starter',
      duration: '1 Month',
      price: '999',
      features: [
        'Full Gym Access',
        'Locker Room Access',
        'Basic Workout Plan',
        'Free Consultation',
      ],
      popular: false,
    },
    {
      name: 'Pro',
      duration: '3 Months',
      price: '1999',
      features: [
        'Full Gym Access',
        'Locker Room Access',
        'Personalized Workout Plan',
        'Diet Consultation',
        '1 Personal Training Session',
      ],
      popular: true,
    },
    {
      name: 'Elite',
      duration: '5 Months',
      price: '2499',
      features: [
        'Full Gym Access',
        'Locker Room Access',
        'Custom Diet & Workout Plan',
        'Bi-weekly Progress Tracking',
        '3 Personal Training Sessions',
        'Yoga Class Access',
      ],
      popular: false,
    },
  ];

  const handleGetStarted = (plan: any) => {
    setSelectedPlan(plan);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `Hello Royal Gym J.K Complex! 👋%0A%0AI am interested in joining the *${selectedPlan.name}* plan.%0A%0A*Plan Details:*%0A- Duration: ${selectedPlan.duration}%0A- Price: ₹${selectedPlan.price}%0A%0A*My Details:*%0A- Name: ${formData.name}%0A- Phone: ${formData.phone}%0A%0APlease guide me further!`;
    
    window.open(`https://wa.me/916202793200?text=${message}`, '_blank');
    setIsModalOpen(false);
    setFormData({ name: '', phone: '' });
  };

  return (
    <section id="membership" className="py-24 bg-zinc-950 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-yellow-400 font-bold uppercase tracking-widest text-sm mb-4 block"
          >
            Pricing Plans
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-black font-display uppercase italic text-white"
          >
            Choose Your <span className="text-yellow-400">Plan</span>
          </motion.h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`relative p-1 rounded-3xl ${
                plan.popular ? 'bg-gradient-to-b from-yellow-400 to-orange-500 scale-105 z-10' : 'bg-white/5'
              }`}
            >
              <div className="bg-zinc-900 rounded-[22px] p-8 h-full flex flex-col">
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-yellow-400 text-black px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-1 shadow-lg">
                    <Zap className="w-3 h-3 fill-current" /> Most Popular
                  </div>
                )}
                
                <div className="mb-8">
                  <h3 className="text-zinc-500 font-bold uppercase tracking-widest text-sm mb-2">{plan.name}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-black text-white">₹{plan.price}</span>
                    <span className="text-zinc-500 text-sm font-medium">/ {plan.duration}</span>
                  </div>
                </div>

                <ul className="space-y-4 mb-10 flex-grow">
                  {plan.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-center gap-3 text-zinc-400 text-sm">
                      <div className="w-5 h-5 rounded-full bg-yellow-400/10 flex items-center justify-center text-yellow-400 flex-shrink-0">
                        <Check className="w-3 h-3" />
                      </div>
                      {feature}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleGetStarted(plan)}
                  className={`w-full py-4 rounded-xl font-black uppercase tracking-wider transition-all duration-300 ${
                    plan.popular
                      ? 'bg-yellow-400 text-black hover:bg-yellow-300 shadow-[0_0_20px_rgba(250,204,21,0.2)]'
                      : 'bg-white/5 text-white hover:bg-white/10 border border-white/10'
                  }`}
                >
                  Get Started
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Membership Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-md bg-zinc-900 border border-white/10 rounded-3xl p-8 shadow-2xl overflow-hidden"
            >
              {/* Decorative background */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-400/10 rounded-full -mr-16 -mt-16 blur-3xl" />
              
              <div className="flex justify-between items-start mb-6 relative z-10">
                <div>
                  <h3 className="text-2xl font-black text-white uppercase italic tracking-tight">
                    Join <span className="text-yellow-400">{selectedPlan?.name}</span>
                  </h3>
                  <p className="text-zinc-500 text-sm font-bold uppercase tracking-widest mt-1">
                    ₹{selectedPlan?.price} / {selectedPlan?.duration}
                  </p>
                </div>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 hover:bg-white/5 rounded-full transition-colors text-zinc-500 hover:text-white"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Your Name</label>
                  <input
                    required
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter your full name"
                    className="w-full bg-zinc-950 border border-white/10 rounded-xl px-4 py-4 text-white placeholder:text-zinc-700 focus:outline-none focus:border-yellow-400/50 transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Phone Number</label>
                  <input
                    required
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Enter your phone number"
                    className="w-full bg-zinc-950 border border-white/10 rounded-xl px-4 py-4 text-white placeholder:text-zinc-700 focus:outline-none focus:border-yellow-400/50 transition-colors"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-yellow-400 text-black py-5 rounded-xl font-black uppercase tracking-widest hover:bg-yellow-300 transition-all flex items-center justify-center gap-3 shadow-[0_10px_30px_rgba(250,204,21,0.2)] group"
                  >
                    Confirm & Send <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                  <p className="text-center text-[10px] text-zinc-600 uppercase tracking-widest font-bold mt-4">
                    This will open WhatsApp to complete your registration
                  </p>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default Membership;
