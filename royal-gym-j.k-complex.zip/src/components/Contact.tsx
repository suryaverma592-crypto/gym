import React from 'react';
import { motion } from 'motion/react';
import { Phone, MapPin, Mail, MessageCircle, Send } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Info Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-yellow-400 font-bold uppercase tracking-widest text-sm mb-4 block">Get In Touch</span>
            <h2 className="text-4xl md:text-5xl font-black font-display mb-8 uppercase italic leading-tight text-white">
              Ready to <br />
              <span className="text-yellow-400 text-gradient">Join the Elite?</span>
            </h2>
            <p className="text-zinc-400 text-lg mb-10 leading-relaxed">
              Have questions about our memberships or training programs? Reach out to us or visit our facility in Bettiah. We're here to help you reach your goals.
            </p>

            <div className="space-y-8 mb-10">
              <div className="flex items-start gap-6">
                <div className="w-14 h-14 rounded-2xl bg-zinc-950 flex items-center justify-center text-yellow-400 border border-white/5 shadow-xl">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white mb-1 uppercase tracking-widest text-sm">Location</h4>
                  <p className="text-zinc-500 text-sm">Near Mahawat Toli, Civil Court Bettiah,<br />West Champaran, Bihar</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-14 h-14 rounded-2xl bg-zinc-950 flex items-center justify-center text-yellow-400 border border-white/5 shadow-xl">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white mb-1 uppercase tracking-widest text-sm">Phone</h4>
                  <p className="text-zinc-500 text-sm">+91 6202793200</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-14 h-14 rounded-2xl bg-zinc-950 flex items-center justify-center text-yellow-400 border border-white/5 shadow-xl">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white mb-1 uppercase tracking-widest text-sm">Email</h4>
                  <p className="text-zinc-500 text-sm">info@royalgymbettiah.com</p>
                </div>
              </div>
            </div>

            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="https://wa.me/916202793200"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-green-500 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-wider hover:bg-green-600 transition-colors shadow-[0_10px_30px_rgba(34,197,94,0.3)]"
            >
              <MessageCircle className="w-6 h-6 fill-current" /> Chat on WhatsApp
            </motion.a>
          </motion.div>

          {/* Form Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-zinc-950 p-10 rounded-3xl border border-white/5 shadow-2xl"
          >
            <form className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Full Name</label>
                  <input
                    type="text"
                    placeholder="John Doe"
                    className="w-full bg-zinc-900 border border-white/5 rounded-xl px-4 py-4 text-white placeholder:text-zinc-700 focus:outline-none focus:border-yellow-400/50 transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+91 00000 00000"
                    className="w-full bg-zinc-900 border border-white/5 rounded-xl px-4 py-4 text-white placeholder:text-zinc-700 focus:outline-none focus:border-yellow-400/50 transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Service Interested In</label>
                <select className="w-full bg-zinc-900 border border-white/5 rounded-xl px-4 py-4 text-white focus:outline-none focus:border-yellow-400/50 transition-colors appearance-none">
                  <option>Personal Training</option>
                  <option>Weight Loss Training</option>
                  <option>Yoga Classes</option>
                  <option>General Membership</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-500 ml-1">Message</label>
                <textarea
                  rows={4}
                  placeholder="How can we help you?"
                  className="w-full bg-zinc-900 border border-white/5 rounded-xl px-4 py-4 text-white placeholder:text-zinc-700 focus:outline-none focus:border-yellow-400/50 transition-colors resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-yellow-400 text-black py-5 rounded-xl font-black uppercase tracking-widest hover:bg-yellow-300 transition-all flex items-center justify-center gap-3 shadow-[0_10px_30px_rgba(250,204,21,0.2)]"
              >
                Send Message <Send className="w-5 h-5" />
              </button>
            </form>
          </motion.div>
        </div>

        {/* Map Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-24 rounded-3xl overflow-hidden h-[400px] border border-white/5 grayscale invert opacity-80 hover:grayscale-0 hover:invert-0 hover:opacity-100 transition-all duration-700"
        >
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3568.123456789012!2d84.50!3d26.80!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDQ4JzAwLjAiTiA4NMKwMzAnMDAuMCJF!5e0!3m2!1sen!2sin!4v1234567890123"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;
