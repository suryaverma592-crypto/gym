import React from 'react';
import { motion } from 'motion/react';
import { ChevronRight, Play } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="relative h-screen flex items-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop"
          alt="Gym Background"
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl"
        >
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-block px-4 py-1 rounded-full bg-yellow-400/10 text-yellow-400 text-sm font-bold uppercase tracking-widest mb-6 border border-yellow-400/20"
          >
            5 Years of Excellence
          </motion.span>
          <h1 className="text-5xl md:text-7xl font-black font-display leading-tight mb-6 uppercase italic">
            Royal Gym <br />
            <span className="text-yellow-400">J.K Complex</span>
          </h1>
          <p className="text-zinc-400 text-lg md:text-xl mb-10 max-w-lg leading-relaxed">
            Transform your body and mind at Bettiah's premier fitness destination. Expert training, state-of-the-art equipment, and a community that pushes you further.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <motion.a
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              href="#membership"
              className="flex items-center justify-center gap-2 bg-yellow-400 text-black px-8 py-4 rounded-full font-black uppercase tracking-wider hover:bg-yellow-300 transition-colors"
            >
              Start Your Journey <ChevronRight className="w-5 h-5" />
            </motion.a>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center justify-center gap-2 bg-white/10 backdrop-blur-md text-white px-8 py-4 rounded-full font-black uppercase tracking-wider hover:bg-white/20 transition-colors border border-white/10"
            >
              <Play className="w-5 h-5 fill-current" /> Watch Promo
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* Stats Overlay */}
      <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-zinc-950 to-transparent pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/10 pt-10">
            {[
              { label: 'Active Members', value: '500+' },
              { label: 'Expert Trainers', value: '5+' },
              { label: 'Years Experience', value: '5' },
              { label: 'Success Stories', value: '1000+' },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="text-center md:text-left"
              >
                <div className="text-3xl font-black text-yellow-400 font-display">{stat.value}</div>
                <div className="text-zinc-500 text-sm uppercase tracking-widest font-bold">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
