import React from 'react';
import { Dumbbell, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-zinc-950 pt-20 pb-10 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <Dumbbell className="w-8 h-8 text-yellow-400" />
              <span className="text-2xl font-black tracking-tighter uppercase font-display">
                Royal <span className="text-yellow-400">Gym</span>
              </span>
            </div>
            <p className="text-zinc-500 max-w-md leading-relaxed mb-8">
              Bettiah's premier fitness destination. We are committed to providing the best training environment and expert guidance to help you achieve your fitness goals.
            </p>
            <div className="flex gap-4">
              {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-400 hover:text-yellow-400 hover:bg-yellow-400/10 transition-all border border-white/5"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-6">Quick Links</h4>
            <ul className="space-y-4">
              {['Home', 'About Us', 'Services', 'Membership', 'Gallery', 'Contact'].map((item) => (
                <li key={item}>
                  <a href={`#${item.toLowerCase().replace(' ', '')}`} className="text-zinc-500 hover:text-yellow-400 transition-colors text-sm">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-6">Working Hours</h4>
            <ul className="space-y-4 text-sm">
              <li className="flex justify-between text-zinc-500">
                <span>Mon - Sat:</span>
                <span className="text-white font-medium">5:00 AM - 10:00 PM</span>
              </li>
              <li className="flex justify-between text-zinc-500">
                <span>Sunday:</span>
                <span className="text-yellow-400 font-medium">Closed</span>
              </li>
            </ul>
            <div className="mt-8 p-4 bg-yellow-400/5 rounded-xl border border-yellow-400/10">
              <p className="text-yellow-400 text-xs font-bold uppercase tracking-widest text-center">
                Join Today & Get 10% Off
              </p>
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-zinc-600 text-xs uppercase tracking-widest font-bold">
            © 2026 Royal Gym J.K Complex. All Rights Reserved.
          </p>
          <div className="flex gap-8 text-zinc-600 text-xs uppercase tracking-widest font-bold">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
