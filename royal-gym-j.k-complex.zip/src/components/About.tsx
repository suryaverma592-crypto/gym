import React from 'react';
import { motion } from 'motion/react';
import { Award, Users, Clock, MapPin } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-24 bg-zinc-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=2070&auto=format&fit=crop"
                alt="Trainer Rocky"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Experience Badge */}
            <div className="absolute -bottom-6 -right-6 bg-yellow-400 text-black p-8 rounded-2xl shadow-2xl">
              <div className="text-4xl font-black font-display">5+</div>
              <div className="text-sm font-bold uppercase tracking-tighter leading-tight">Years of<br />Experience</div>
            </div>
            {/* Decorative Element */}
            <div className="absolute -top-6 -left-6 w-32 h-32 border-l-4 border-t-4 border-yellow-400 rounded-tl-3xl z-[-1]" />
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-yellow-400 font-bold uppercase tracking-widest text-sm mb-4 block">Our Story</span>
            <h2 className="text-4xl md:text-5xl font-black font-display mb-8 uppercase italic leading-tight">
              Leading Fitness in <br />
              <span className="text-yellow-400">Bettiah Since 2021</span>
            </h2>
            <p className="text-zinc-400 text-lg mb-8 leading-relaxed">
              Royal Gym J.K Complex is more than just a gym; it's a community dedicated to achieving peak physical performance. Located in the heart of Civil Court Bettiah, we provide a world-class environment for everyone from beginners to professional athletes.
            </p>

            <div className="grid sm:grid-cols-2 gap-6 mb-10">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-zinc-900 rounded-xl text-yellow-400">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white mb-1">Expert Coaching</h4>
                  <p className="text-zinc-500 text-sm">Guided by Punit Kumar (Rocky), 5 years exp.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-zinc-900 rounded-xl text-yellow-400">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-white mb-1">Community</h4>
                  <p className="text-zinc-500 text-sm">Join 500+ motivated members.</p>
                </div>
              </div>
            </div>

            <div className="bg-zinc-900/50 p-8 rounded-2xl border border-white/5">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-yellow-400 flex items-center justify-center text-black font-black">PK</div>
                <div>
                  <h4 className="font-bold text-white">Punit Kumar (Rocky)</h4>
                  <p className="text-yellow-400 text-xs uppercase font-bold tracking-widest">Head Trainer & Founder</p>
                </div>
              </div>
              <p className="text-zinc-400 italic text-sm leading-relaxed">
                "Fitness is not about being better than someone else. It's about being better than you were yesterday. At Royal Gym, we provide the tools, but you bring the fire."
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
